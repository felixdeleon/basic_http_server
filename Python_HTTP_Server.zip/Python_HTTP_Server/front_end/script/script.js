button = document.querySelector('.my_btn');
button.onclick = ()=>{
    button.classList.toggle('float');
}